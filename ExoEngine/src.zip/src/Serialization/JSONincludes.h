#pragma once
//All include files for rapidJSON

#include "rapidjson/include/rapidjson/rapidjson.h"		// Main include for RapidJSON
#include "rapidjson/include/rapidjson/document.h"		// rapidjson's DOM-style API
#include "rapidjson/include/rapidjson/stringbuffer.h"	// wrapper of C stream for prettywriter as output
#include "rapidjson/include/rapidjson/prettywriter.h"	// for stringify JSON
