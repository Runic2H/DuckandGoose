#include "empch.h"
#include "Button.h"

EM::Button::Button()
{
}

bool EM::Button::Deserialize(const rapidjson::Value& obj)
{
	return true;
}

bool EM::Button::Serialize(rapidjson::PrettyWriter<rapidjson::StringBuffer>* writer) const
{	
		
	return true;
}
