//precompile header
#include"empch.h"